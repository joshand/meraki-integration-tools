from appicm.models import *
import base64
import requests
import json


# def_icon = "https://cdn.umbrella.marketops.umbrella.com/wp-content/uploads/2020/02/25170753/2020_q1_web_blade-10-icons-01.svg"


def get_home_link(ctl):
    org_id = ctl.authparm.get("api", {}).get("orgid", None)

    if not org_id:
        return ctl.mgmtaddress

    return "https://dashboard.umbrella.com/o/" + org_id + "/#/overview"


def getorgs(args):
    base64_value = args[1] + ':' + args[2]
    message_bytes = base64_value.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')
    headers = {'Authorization': 'Basic ' + base64_message}

    # url for organizations in umbrella dashboard
    org_url = args[0] + "/organizations"
    ret = requests.get(org_url, headers=headers)
    o_out = []
    try:
        for org in ret.json():
            o_out.append({"id": org["organizationId"], "organizationId": org["organizationId"], "name": org["name"]})
    except Exception:
        print(args)
        print(ret.content.decode("utf-8"))

    return o_out


# def config_connection(request, tenant_id):
#     if request.method == 'POST':
#         int_id = request.POST.get("objId")
#         int_desc = request.POST.get("objDesc")
#         int_sec = request.POST.get("objSec")
#         int_key = request.POST.get("objKey")
#         int_org = request.POST.get("objOrg")
#         if int_id is None or int_id == "":
#             dt = DeviceType.objects.filter(name="Umbrella")
#             authdata = {"api": {"orgid": int_org, "secret": int_sec, "key": int_key, "baseurl": "https://management.api.umbrella.com/v1"}}
#             cont = Controller.objects.create(name=int_desc, devicetype=dt[0], authparm=authdata, tenant_id=tenant_id)
#             orgurl = get_basic_data(cont, "orgurl", default="https://dashboard.umbrella.com")
#             HomeLink.objects.create(name=int_desc, url=orgurl, controller=cont, icon_url=def_icon)
#         else:
#             controllers = Controller.objects.filter(id=int_id)
#             if len(controllers) == 1:
#                 cont = controllers[0]
#                 cont.name = int_desc
#                 cont.authparm["api"]["orgid"] = int_org
#                 cont.authparm["api"]["key"] = int_key
#                 if int_sec.find("*") < 0:
#                     cont.authparm["api"]["secret"] = int_sec
#                 cont.save()
#                 orgurl = get_basic_data(cont, "orgurl", default="https://dashboard.umbrella.com")
#                 HomeLink.objects.update_or_create(controller=cont, tenant_id=tenant_id,
#                                                   defaults={"name": int_desc, "url": orgurl, "icon_url": def_icon})
# 
#     if request.GET.get("action") == "delorg":
#         mer_id = request.GET.get("id")
#         Controller.objects.filter(id=mer_id).delete()
# 
#     dashboards = Controller.objects.filter(tenant=tenant_id).filter(devicetype__name="Umbrella")
# 
#     return {"template": "home/config_umbrella.html", "desc": "Umbrella", "data": dashboards}


def process_umbrella_inventory(tenant):
    retdata = "--This is the Umbrella Discovery module--\n"
    controllers = Controller.objects.filter(tenant=tenant).filter(devicetype__name="Umbrella")
    if len(controllers) == 0:
        return None

    for c in controllers:
        base_url = c.authparm.get("api", {}).get("baseurl")
        api_key = c.authparm.get("api", {}).get("mgmtkey")
        api_secret = c.authparm.get("api", {}).get("mgmtsecret")
        org_id = c.authparm.get("api", {}).get("orgid")

        if not api_key or not api_secret:
            continue
        base64_value = api_key + ':' + api_secret
        message_bytes = base64_value.encode('ascii')
        base64_bytes = base64.b64encode(message_bytes)
        base64_message = base64_bytes.decode('ascii')
        headers = {'Authorization': 'Basic ' + base64_message}

        # url for network tunnels in umbrella dashboard
        tunnel_url = base_url + "/organizations/"+org_id+"/tunnels"
        ret = requests.get(tunnel_url, headers=headers)

        # save new tunnels
        existing_tunnel_ids = []
        for tun in ret.json():
            existing_tunnel_ids.append(str(tun["id"]))
            t, cr = Tunnel.objects.update_or_create(tenant=tenant, tunnelId=tun["id"],
                                                    defaults={"name": tun["name"], "rawdata": tun, "controller": c})
            if not cr:
                t.rawdata = tun
                t.save()
                retdata += "updated tunnel '" + tun["name"] + "'\n"
            else:
                retdata += "created tunnel '" + tun["name"] + "'\n"

        # clean up non-existant tunnels
        dbtuns = Tunnel.objects.filter(tenant=tenant).filter(controller=c)
        for dbtun in dbtuns:
            # print(dbtun.tunnelId, existing_tunnel_ids)
            if str(dbtun.tunnelId) not in existing_tunnel_ids:
                retdata += "removed superfluous tunnel '" + dbtun.name + "'\n"
                dbtun.delete()

    return retdata


def do_sync(tenant_list=None):
    if not tenant_list:
        tenants = Tenant.objects.exclude(name="Default")
    else:
        tenants = Tenant.objects.filter(id__in=tenant_list)

    for tenant in tenants:
        ret = process_umbrella_inventory(tenant)
        if ret:
            TaskResult.objects.create(tenant=tenant, taskname="sync_umbrella", result=ret)


def run():
    do_sync()
